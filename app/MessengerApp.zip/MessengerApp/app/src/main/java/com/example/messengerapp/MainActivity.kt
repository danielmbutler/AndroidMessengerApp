package com.example.messengerapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        RegisterButton.setOnClickListener {

            val email = Email_EditText_RegScreen.text.toString()
            val password = Password_EditText_RegScreen.text.toString()
            Log.d("MainActivity", "Email is " + email)
            Log.d("MainActivity", "Password : $password")

        }

        // authenticate with firebase


        NavToLoginPage.setOnClickListener {
            Log.d("MainActivity","show login activity")

            // launch login activity

            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }


    }
}